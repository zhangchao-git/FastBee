package com.fastbee.data.config;

/**
 * @author gsb
 * @date 2022/10/26 11:13
 */
public class TaskConfig {
}
