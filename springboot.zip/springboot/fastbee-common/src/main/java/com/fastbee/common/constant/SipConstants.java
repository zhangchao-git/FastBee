package com.fastbee.common.constant;

public class SipConstants {
    public static final String MESSAGE_CATALOG = "Catalog";
    public static final String MESSAGE_KEEP_ALIVE = "Keepalive";
    public static final String MESSAGE_DEVICE_INFO = "DeviceInfo";
    public static final String MESSAGE_RECORD_INFO = "RecordInfo";
    public static final String MESSAGE_MEDIA_STATUS = "MediaStatus";
}
