package com.fastbee.base.core.model;

/**
 * 消息流水号响应
 * @author gsb
 * @date 2022/11/7 10:19
 */
public interface Response {

    /**应答消息流水号*/
    int getResponseSerialNo();
}
