package com.fastbee.base.core.annotation;

import java.lang.annotation.*;

/**
 * 消息节点
 * @author bill
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Node {

}
